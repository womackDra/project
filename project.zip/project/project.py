
import tkinter as tk

#function
def openFood():
    foodwindow = tk.Tk()
    #menu
    chili = tk.Button(foodwindow,command=openChili, text = "Chili")
    chili.pack()
    sandwiches = tk.Button(foodwindow,command=opensandwiches, text = "Sandwiches")
    sandwiches.pack()
    sides = tk.Button(foodwindow,command=opensides, text = "Sides")
    sides.pack()
    
def openOrder():
    orderwindow = tk.Tk()

def openLowCarb():
    lowCarbWindow = tk.Tk()

def openChili():
    chiliWindow = tk.Tk()

def opensandwiches():
    sandwichesWindow = tk.Tk()

def opensides():
    sidesWindow = tk.Tk()


#window 
window = tk.Tk()
#button 
button1 = tk.Button(command=openFood, text = "Menu")
button1.pack()

button2 = tk.Button(command=openOrder, text = "Check Order" )
button2.pack()    

window.mainloop()